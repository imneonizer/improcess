from improcess.improcess import multi_processing, console_log

def stop():
    raise Exception('stop_process')


